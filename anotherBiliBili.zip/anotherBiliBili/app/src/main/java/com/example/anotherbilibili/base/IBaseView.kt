package com.example.anotherbilibili.base

interface IBaseView {

    fun showIsLoading()

    fun removeLoading()

}