package com.example.anotherbilibili.network

object UrlFixed {

const val  RecommendUrl="https://www.apiopen.top/satinApi"


}