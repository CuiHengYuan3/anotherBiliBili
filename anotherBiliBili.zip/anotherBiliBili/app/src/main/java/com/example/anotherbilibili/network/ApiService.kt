package com.example.anotherbilibili.network

import com.example.anotherbilibili.mvp.Bean.RecommendBean
import io.reactivex.Observable
import retrofit2.http.GET

interface ApiService {

    @GET()
    fun getRecommendData(): Observable<RecommendBean>


}